<?php

    namespace App\Http\Controllers\Api;

    use App\Http\Controllers\Controller;
    use App\Models\Category;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;

    class ApiController extends Controller
    {

        public function __construct()
        {   
            // $this->middleware('authorization');
        }

        public function categories(Request $request)
        {
            $categories = Category::with('indicators')->get();

            $formattedData = [];
            foreach ($categories as $category) {
                $formattedCategory = [
                    'name' => $category->name,
                    'indicators' => $category->indicators->map(function ($indicator) {
                        return [
                            'id' => $indicator->id,
                            'indicator' => $indicator->indicator,
                            'definition' => $indicator->definition,
                            'type' => $indicator->type,
                            'data' => $indicator->data,
                        ];
                    }),
                ];
                $formattedData[] = $formattedCategory;
            }

            return response()->json(['data'=>$formattedData,'status'=>"success"], 200);

        }

    }