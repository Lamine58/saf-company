<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0"><?php echo e($title); ?> à  <?php echo e($category->name); ?></h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Indicateur</a></li>
                                    <li class="breadcrumb-item active"><?php echo e($title); ?> à  <?php echo e($category->name); ?></li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <form action="<?php echo e(route('indicator.save')); ?>" class="add_indicator">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($indicator->id); ?>">
                    <input type="hidden" name="categorie_id" value="<?php echo e($category->id); ?>">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="row g-3">
    
                                                <div class="col-lg-6">
                                                    <label class="form-label">Indicateur</label>
                                                    <textarea id="indicator" class="form-control rounded-end" name="indicator" rows="3"><?php echo e($indicator->indicator); ?></textarea>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div>
                                                        <label class="form-label">Définition</label>
                                                        <textarea name="definition" id="definition" class="form-control rounded-end" rows="3"><?php echo e($indicator->definition); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <select name="method_id" id="method_id" class="form-control rounded-end mt-1">
                                                        <option value="">Méthode de collecte de donnée</option>
                                                        <?php $__currentLoopData = App\Models\Method::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                                                            <option <?php echo e($indicator->method_id==$data->id ? 'selected' : ''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-lg-6">
                                                    <select name="unity_id" id="unity_id" class="form-control rounded-end mt-1">
                                                        <option value="">Unité</option>
                                                        <?php $__currentLoopData = App\Models\Unity::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                                                            <option <?php echo e($indicator->unity_id==$data->id ? 'selected' : ''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-lg-6">
                                                    <select name="periodicity_id" id="periodicity_id" class="form-control rounded-end mt-1">
                                                        <option value="">Periodicité</option>
                                                        <?php $__currentLoopData = App\Models\Periodicity::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                                                            <option <?php echo e($indicator->periodicity_id==$data->id ? 'selected' : ''); ?> value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-lg-6">
                                                    <select name="type" id="type" class="form-control rounded-end mt-1">
                                                        <option <?php echo e($indicator->type=='Nombre' ? 'selected' : ''); ?> >Nombre</option>
                                                        <option <?php echo e($indicator->type=='Text' ? 'selected' : ''); ?> >Text</option>
                                                        <option <?php echo e($indicator->type=='Long text' ? 'selected' : ''); ?> >Long text</option>
                                                        <option <?php echo e($indicator->type=='Indicateur à choix unique' ? 'selected' : ''); ?> >Indicateur à choix unique</option>
                                                        <option <?php echo e($indicator->type=='Indicateur à choix multiple' ? 'selected' : ''); ?> >Indicateur à choix multiple</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6"></div>
                                                <div class="col-lg-4 choice choice-class <?php echo e(($indicator->type=='Indicateur à choix unique' || $indicator->type=='Indicateur à choix multiple') ? '' : 'hidden'); ?> ">
                                                    <?php $__currentLoopData = json_decode($indicator->data ?? '[]'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <input placeholder="Option de reponse" value='<?php echo e($choice); ?>' class="form-control rounded-end mt-1" name="data[]">
                                                            </div>
                                                            <div class="col-md-2">
                                                                <button onclick="remove_item(this)" class="btn btn-danger"><i class="ri-delete-bin-fill"></i></button>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="col-lg-2 choice-class <?php echo e(($indicator->type=='Indicateur à choix unique' || $indicator->type=='Indicateur à choix multiple') ? '' : 'hidden'); ?> "><button id="add-choice" type="button"  style="width:100%" class="btn btn-block btn-primary btn-sm"><i class="ri-add-fill"></i> Ajouter une option</button></div>
                                                <div class="col-lg-12">
                                                    <button id="add_indicator" class="btn btn-primary btn-block" style="width:100%">Enregistrer</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- end card body -->
                            </div>
                            <!-- end card -->
                        </div>
                        <!-- end col -->
                    </div>
                </form>


            </div>
            <!-- container-fluid -->
        </div>
        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css-link'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>

        $('#type').on('change',()=>{

            if($('#type').val()=='Indicateur à choix unique' || $('#type').val()=='Indicateur à choix multiple'){
                $('.choice-class').removeClass('hidden');
            }else{
                $('.choice-class').addClass('hidden');
            }
        });

        $('#add-choice').on('click',function(){
            $('.choice').append(`
                <div class="row">
                    <div class="col-md-10">
                        <input placeholder="Option de reponse" class="form-control rounded-end mt-1" name="data[]">
                    </div>
                    <div class="col-md-2">
                        <button onclick="remove_item(this)" class="btn btn-danger"><i class="ri-delete-bin-fill"></i></button>
                    </div>
                </div>
            `);
        });

        function remove_item(self){
            $(self).parent().parent().remove();
        }

        $('.add_indicator').submit(function(e){

            e.preventDefault();

            var form = new FormData($(this)[0]);

            var buttonDefault = $('#add_indicator').text();
            var button = $('#add_indicator');

            button.attr('disabled',true);
            button.text('Veuillez patienter ...');

            $.ajax({
                type: 'POST',
                url: $(this).attr('action'),
                data: form,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (result){

                    button.attr('disabled',false);
                    button.text(buttonDefault);

                    if(result.status=="success"){

                        Toastify({
                            text: result.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "#4CAF50", // green
                        }).showToast();

                        window.location='<?php echo e(route('indicator.index',[$category->id])); ?>'
                    }else{
                        Toastify({
                            text: result.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }
                    
                },
                error: function(result){

                    button.attr('disabled',false);
                    button.text(buttonDefault);

                    if(result.responseJSON.message){
                        Toastify({
                            text: result.responseJSON.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }else{
                        Toastify({
                            text: "Une erreur c'est produite",
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }

                }
            });
        });

    </script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\laravel\sisrah\resources\views/indicator/save.blade.php ENDPATH**/ ?>