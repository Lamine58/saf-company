<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0"><?php echo e($title); ?></h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Fournisseurs</a></li>
                                    <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>

                <form action="<?php echo e(route('user.save')); ?>" class="add_user">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <input type="file" name="avatar" class="dropify" data-default-file="<?php echo e($user->avatar!=null ? Storage::url($user->avatar) : ''); ?>">
                                        </div>
                                        <div class="col-md-10">
                                            <div class="row g-3">
    
                                                <div class="col-lg-6">
                                            
                                                    <div >
                                                        <label class="form-label">Type de compte</label>
                                                        <select name="account" id="account" class="form-control">
                                                            <?php if(Auth::user()->account=='ADMINISTRATEUR' || Auth::user()->account=='MINISTERE'): ?>
                                                                <option <?php echo e($user->account=="ADMINISTRATEUR" ? 'selected' : ''); ?> >ADMINISTRATEUR</option>
                                                                <option <?php echo e($user->account=="MINISTERE" ? 'selected' : ''); ?>>MINISTERE</option>
                                                                <option <?php echo e($user->account=="FOURNISSEUR" ? 'selected' : ''); ?>>FOURNISSEUR</option>
                                                                <option <?php echo e($user->account=="ENQUETEUR" ? 'selected' : ''); ?>>ENQUETEUR</option>
                                                            <?php else: ?>
                                                                <option <?php echo e($user->account=="FOURNISSEUR" ? 'selected' : ''); ?>>FOURNISSEUR</option>
                                                                <option <?php echo e($user->account=="ENQUETEUR" ? 'selected' : ''); ?>>ENQUETEUR</option>
                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
        
                                                    <?php if(Auth::user()->account=='ADMINISTRATEUR' || Auth::user()->account=='MINISTERE'): ?>
                                                        <div  class="mt-3 <?php echo e($user->business_id==null ? 'hidden' : ''); ?> business">
                                                            <label class="form-label">Fournisseur</label>
                                                            <select id="business_id" class="form-control" name="business_id"> 
                                                                <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($business->id); ?>" <?php echo e($business->id==$user->business_id ? 'selected' : ''); ?> ><?php echo e($business->legal_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    <?php else: ?>
                                                        <input type="hidden" name="business_id" value="<?php echo e(Auth::user()->business_id); ?>">
                                                    <?php endif; ?>

                                                    
                                                    <div  class="mt-3 <?php echo e($user->account=='ENQUETEUR' ? '' : 'hidden'); ?> query">
                                                        <label class="form-label">Zone</label>
                                                        <select id="zone_id" class="form-control" name="zone_id"> 
                                                            <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($zone->id); ?>" <?php echo e($zone->id==$user->zone_id ? 'selected' : ''); ?> ><?php echo e($zone->name); ?> - <?php echo e($zone->departement); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
        
                                                    <div class="mt-3">
                                                        <label class="form-label">Email</label>
                                                        <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control rounded-end" />
                                                    </div>
                                                </div>
        
                                                <div class="col-lg-6">
        
                                                    <div>
                                                        <label class="form-label">Nom</label>
                                                        <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>" class="form-control rounded-end" />
                                                    </div>
        
                                                    <div  class="mt-3">
                                                        <label class="form-label">Prénom</label>
                                                        <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>" class="form-control rounded-end" />
                                                    </div>
        
                                                    <div  class="mt-3">
                                                        <label class="form-label">Téléphone</label>
                                                        <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control rounded-end phone" />
                                                    </div>
                                                    <br>
                                                </div>
                                                <div class="col-lg-12 row mt-2">
                                                    <h4><small>Accès</small></h4>
                                                    <hr>
                                                    <div class="col-lg-6">
                                                        <label class="form-label">Mot de passe</label>
                                                        <input type="text" name="password" class="form-control rounded-end" />
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label class="form-label">Confirmer  le mot de passe</label>
                                                        <input type="text" name="password_confirmation" class="form-control rounded-end" />
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <button id="add_user" class="btn btn-primary btn-block" style="width:100%">Enregistrer</button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- end card body -->
                            </div>
                            <!-- end card -->
                        </div>
                        <!-- end col -->
                    </div>
                </form>


            </div>
            <!-- container-fluid -->
        </div>
        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css-link'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>

        $('#account').on('change',()=>{

            if($('#account').val()=='FOURNISSEUR' || $('#account').val()=='ENQUETEUR'){
                $('.business').removeClass('hidden');
            }else{
                $('.business').addClass('hidden');
            }

            if($('#account').val()=='ENQUETEUR'){
                $('.query').removeClass('hidden');
            }else{
                $('.query').addClass('hidden');
            }

        });

        $('.add_user').submit(function(e){

            e.preventDefault();

            var form = new FormData($(this)[0]);

            var buttonDefault = $('#add_user').text();
            var button = $('#add_user');

            button.attr('disabled',true);
            button.text('Veuillez patienter ...');

            $.ajax({
                type: 'POST',
                url: $(this).attr('action'),
                data: form,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (result){

                    button.attr('disabled',false);
                    button.text(buttonDefault);

                    if(result.status=="success"){

                        Toastify({
                            text: result.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "#4CAF50", // green
                        }).showToast();

                        window.location='<?php echo e(route("user.index")); ?>'
                    }else{
                        Toastify({
                            text: result.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }
                    
                },
                error: function(result){

                    button.attr('disabled',false);
                    button.text(buttonDefault);

                    if(result.responseJSON.message){
                        Toastify({
                            text: result.responseJSON.message,
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }else{
                        Toastify({
                            text: "Une erreur c'est produite",
                            duration: 3000, // 3 seconds
                            gravity: "top", // "top" or "bottom"
                            position: 'right', // "left", "center", "right"
                            backgroundColor: "red", // red
                        }).showToast();
                    }

                }
            });
        });

    </script>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\laravel\sisrah\resources\views/user/save.blade.php ENDPATH**/ ?>